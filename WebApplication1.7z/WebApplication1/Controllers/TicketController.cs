﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class TicketController : ApiController
    {
        //GET 
        [HttpGet]
        [Route("GetAllTickets")]
        public string GetAllTickets(
            [FromUri] string region
            )
        {
            //JSON model for response
            //{
            //   "x" : "x_value_for_ticket_location",
            //   "y" : "y_value_for_ticket_location",
            //   "ticket": "ticket_number"
            //}

            var result = "[[53.47721822541966,42.53731343283582,'Ticket1']," +
                            "[42.92565947242206,12.313432835820896,'Ticket2']," +
                            "[27.577937649880095,89.55223880597015,'Ticket3']]";

            return result;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Net;
using Newtonsoft.Json;
using System.Xml;

namespace WebAPI.Models
{
    public partial class Tickets 
    {
        public int Id;
        public string Value;

        public Tickets()
        {
            Id = 0;
            Value = "";
        }
    }
}
